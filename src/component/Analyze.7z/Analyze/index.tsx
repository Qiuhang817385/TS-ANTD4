import { Divider, Button, Col, Collapse, Row, Table, Tree, Anchor } from 'antd'
import React, { useEffect, useRef, useState } from 'react'
import { RightOutlined } from '@ant-design/icons'
import Logo from './Logo'
import DescriptionTable from './DescriptionTable'
import style from './index.module.scss'

interface Props {
  startTime?: string
  endTime?: string
}

const { Panel } = Collapse
const { Link } = Anchor

const Index = ({
  startTime = '2021 年 1 月 28 日 10:00:00',
  endTime = '2021 年 1 月 30 日 10:00:00',
}: Props) => {
  const columns28 = [
    {
      title: '模块',
      dataIndex: 'port_address',
    },
    {
      title: '模块类型',
      dataIndex: 'tenant_name',
    },
    {
      title: '持有大小',
      dataIndex: 'tenant_na2me',
    },
    {
      title: '正在使用大小',
      dataIndex: 'teasdnant_na2me',
    },
    {
      title: '块数',
      dataIndex: 'tesasdnant_na2me',
    },
    {
      title: '平均大小',
      dataIndex: 'teasdn3ant_na2me',
    },
  ]

  const menuref = useRef<HTMLDivElement>(null)
  const contentref = useRef<HTMLDivElement>(null)
  const dragRef = useRef<HTMLDivElement>(null)
  const [showMenu, setShowMenu] = useState(true)

  const menuList = [
    {
      title: <Link href="#components-anchor-demo-basic1" title="基本信息" />,
      key: 'basic_info',
      children: [
        {
          title: (
            <Link href="#components-anchor-demo-basic2" title="集群基本信息" />
          ),
          key: 'basic_info1',
        },
        {
          title: (
            <Link href="#components-anchor-demo-basic3" title="节点基本信息" />
          ),
          key: 'basic_info2',
        },
        {
          title: (
            <Link href="#components-anchor-demo-basic4" title="节点资源信息" />
          ),
          key: 'basic_info3',
        },
        {
          title: (
            <Link
              href="#components-anchor-demo-basic5"
              title="节点数据分区信息"
            />
          ),
          key: 'basic_info4',
        },
      ],
    },
    {
      title: (
        <Link href="#components-anchor-demo-basic6" title="工作负载统计信息" />
      ),
      key: 'basic_work_info',
      children: [
        {
          title: (
            <Link href="#components-anchor-demo-basic7" title="集群基本信息" />
          ),
          key: 'basic_work_info1',
        },
        {
          title: (
            <Link href="#components-anchor-demo-basic8" title="OB_Tenant1" />
          ),
          key: 'basic_work_info2',
        },
        {
          title: (
            <Link href="#components-anchor-demo-basic9" title="OB_Tenant2" />
          ),
          key: 'basic_work_info3',
        },
        {
          title: (
            <Link href="#components-anchor-demo-basic10" title="OB_Tenant3" />
          ),
          key: 'basic_work_info4',
        },
      ],
    },
    {
      title: (
        <Link href="#components-anchor-demo-basic11" title="节点统计信息" />
      ),
      key: 'node_info',
    },
    {
      title: (
        <Link href="#components-anchor-demo-basic12" title="SQL 统计信息" />
      ),
      key: 'sql_info',
      children: [
        {
          title: (
            <Link
              href="#components-anchor-demo-basic13"
              title="按照响应时间排序的SQL"
            />
          ),
          key: 'sql_info1',
          children: [
            {
              title: (
                <Link href="#components-anchor-demo-basic14" title="集群范围" />
              ),
              key: 'sql_info_time1',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic15"
                  title="OB_Tenant1"
                />
              ),
              key: 'sql_info_time2',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic16"
                  title="OB_Tenant2"
                />
              ),
              key: 'sql_info_time3',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic17"
                  title="OB_Tenant3"
                />
              ),
              key: 'sql_info_time4',
            },
          ],
        },
        {
          title: (
            <Link
              href="#components-anchor-demo-basic18"
              title="按照 CPU 时间排序的SQL"
            />
          ),
          key: 'sql_info2',
          children: [
            {
              title: (
                <Link href="#components-anchor-demo-basic19" title="集群范围" />
              ),
              key: 'sql_info_cpu1',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic20"
                  title="OB_Tenant1"
                />
              ),
              key: 'sql_info_cpu2',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic21"
                  title="OB_Tenant2"
                />
              ),
              key: 'sql_info_cpu3',
            },
            {
              title: (
                <Link
                  href="#components-anchor-demo-basic22"
                  title="OB_Tenant3"
                />
              ),
              key: 'sql_info_cpu4',
            },
          ],
        },
      ],
    },
  ]

  useEffect(() => {
    if (dragRef.current && menuref.current) {
      dragRef.current.onmousedown = function (eve: any) {
        if (menuref.current && dragRef.current) {
          menuref.current.style.transition = 'width 0s'
          let x: number, t1: number, menuListWidth: number, off: number
          // 点击的地方
          x = eve.clientX
          menuListWidth = menuref.current?.clientWidth
          // 在mid内部鼠标点击的点距离当前盒子左边的距离
          t1 = eve.clientX - dragRef.current?.offsetLeft
          // 0 -7xp
          off = dragRef.current?.offsetLeft - menuListWidth
          document.onmousemove = function (e: any) {
            let MIN = 200
            let MAX = 300
            let incremental = e.clientX - x
            // let posiLeft = e.clientX - t1 - off
            let posiLeft1 = e.clientX - t1
            if (dragRef.current && menuref.current && contentref.current) {
              if (posiLeft1 >= MIN && posiLeft1 <= MAX) {
                dragRef.current.style.left = posiLeft1 + 'px'
                menuref.current.style.width = menuListWidth + incremental + 'px'
                menuref.current.style.minWidth =
                  menuListWidth + incremental + 'px'
                // 这里需要调整
                // contentref.current.style.left =
                //   contentref.current?.clientLeft - incremental + 'px'
              }
            }
          }
          document.onmouseup = function (e: any) {
            document.onmousemove = null
            if (menuref.current) {
              menuref.current.style.transition = 'width 0.3s'
            }
          }
        }
        return false
      }
    }
  }, [])

  const getMenu = (menu: any[]): any => {
    return menu.map((child: any) => {
      if (child.children) {
        return (
          <Collapse ghost={true}>
            <Panel
              key={child.title}
              header={
                <a
                  style={{
                    color: '#000',
                  }}
                  href=""
                >
                  {child.title || ''}
                </a>
              }
            >
              {getMenu(child.children)}
            </Panel>
          </Collapse>
        )
      }
      return (
        <Panel
          className={style.nav}
          showArrow={false}
          key={child.title}
          header={
            <a
              style={{
                color: '#000',
              }}
              href=""
            >
              {child.title || '1'}
            </a>
          }
        />
      )
    })
  }

  return (
    <div className={style.container}>
      <header className={style.header}>
        <div className={style.header_logo}>
          <Logo width={125.7} height={16} />
          <Divider
            type="vertical"
            style={{
              opacity: 0.2,
              width: '1px',
              height: '26px',
              background: '#b8c6d3',
            }}
          />
          <h1>ob2342 的性能报告</h1>
        </div>
        <div className={style.header_content_title}>
          <span>生成时间：2021 年 1 月 28 日 10:00:00</span>
          <span>
            分析范围：{startTime || ''} ~ {endTime || ''}
          </span>
        </div>
        {/* eslint-disable-next-line */}
      </header>
      <div className={style.content}>
        {/* 左侧导航区域 */}
        <nav ref={menuref} className={` ${style.left}`}>
          <Button
            id="toggleMenuShow"
            className={style.toggleMenuShow}
            onClick={() => {
              if (menuref.current && contentref.current) {
                // 需要通过样式来控制，否则导出之后不兼容原生js
                // eslint-disable-next-line
                menuref.current.classList.toggle(`${style.showMenu}`)
                contentref.current.classList.toggle(`${style.showContent}`)
                if (dragRef.current) {
                  dragRef.current.style.right = 0 + 'px'
                }
                setShowMenu((showMenu) => {
                  if (dragRef.current && menuref.current) {
                    if (showMenu) {
                      dragRef.current.style.left = 0 + 'px'
                    } else {
                      dragRef.current.style.left = menuref.current.style.width
                    }
                  }
                  return !showMenu
                })
              }
            }}
          >
            <RightOutlined style={{ fontSize: 10 }} />
          </Button>
          {/* 整体的菜单内容区域 */}
          <Row className={style.menuList}>
            <div
              className="des"
              style={{
                height: 40,
                textAlign: 'left',
                paddingLeft: 30,
              }}
            >
              目录1
            </div>
            <Col span={24}>
              {/* 目录区域 */}
              <Anchor affix={false} showInkInFixed={false}>
                {/* <Tree
                  defaultExpandAll={true}
                  treeData={menuList}
                /> */}
                {getMenu(menuList)}
              </Anchor>
            </Col>
          </Row>
          <div ref={dragRef} className={style.dragRight}></div>
        </nav>
        {/* 右侧内容区域 */}
        <article ref={contentref} className={` ${style.right}`}>
          <div className={style.right_content}>
            <Row gutter={[16, 16]}>
              <Col span={24}>
                <span className={style.data_link_title}>集群基本信息</span>
              </Col>
              <Col span={24}>
                <DescriptionTable />
              </Col>
              <Col span={24}>
                <span className={style.data_link_title}>节点信息1</span>
              </Col>
              <Col span={24}>
                <Table
                  columns={columns28 || []}
                  dataSource={[]}
                  bordered
                  size="small"
                />
              </Col>
              <Col span={24}>
                <span className={style.data_link_title}>节点信息2</span>
              </Col>
              <Col span={24}>
                <Table
                  columns={columns28 || []}
                  dataSource={[]}
                  bordered
                  size="small"
                />
              </Col>
              <Col span={24}>
                <span className={style.data_link_title}>节点信息3</span>
              </Col>
              <Col span={24}>
                <Table
                  columns={columns28 || []}
                  dataSource={[]}
                  bordered
                  size="small"
                />
              </Col>
              <Col id="node4" span={24}>
                <span className={style.data_link_title}>节点信息4</span>
              </Col>
              <Col span={24}>
                <Table
                  columns={columns28 || []}
                  dataSource={[]}
                  bordered
                  size="small"
                />
              </Col>
            </Row>
          </div>
        </article>
      </div>
    </div>
  )
}

export default Index
