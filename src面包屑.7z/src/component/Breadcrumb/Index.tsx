import React, { useEffect, useState } from 'react'
import { Breadcrumb, Button, List, Row } from 'antd'
interface Props {
  pathP?: any
}

const Index = (props: Props) => {
  const { pathP } = props
  const [path, setPath] = useState('')

  // 实际上应该是从路由当中拿到hash值的
  // 不过要动态改变？？
  useEffect(() => {
    setPath(pathP)
  }, [pathP])

  console.log('realPath', pathP)

  const breadcrumbNameMap = {
    '/apps': 'Application List',
    // 集群1
    '/apps/1': '集群1',
    // 集群2
    '/apps/2': '集群2',
    '/apps/1/detail': '集群1的Detail',
    '/apps/2/detail': '集群2的Detail',
  }

  const pathSnippets = path?.split('/')?.filter((i) => i) || []

  const extraBreadcrumbItems: any[] = pathSnippets.map((_, index) => {
    const url = `/${pathSnippets.slice(0, index + 1).join('/')}`
    return (
      <Breadcrumb.Item
        key={index}
        onClick={() => {
          setPath(url)
        }}
      >
        {breadcrumbNameMap[url]}
      </Breadcrumb.Item>
    )
  })
  console.log('extraBreadcrumbItems', extraBreadcrumbItems)

  const breadcrumbItems = [
    <Breadcrumb.Item key="home">Home</Breadcrumb.Item>,
  ].concat(extraBreadcrumbItems)

  return (
    <div>
      <Row>
        <Breadcrumb>{breadcrumbItems}</Breadcrumb>
      </Row>
    </div>
  )
}

export default Index
