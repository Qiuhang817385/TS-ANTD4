import { Avatar, Button, List, Form, Table, Row, Col, Menu, Anchor } from 'antd'
import React, { useEffect, useState } from 'react'
// import { columns, data } from './data'
import Analyze from './component/Analyze'
import { exportElement } from './util/index'
import './App.css'
import './App3.scss'

const { Link } = Anchor
function App() {
  return (
    <>
      <Button
        style={{
          position: 'fixed',
          top: 100,
          right: 50,
          zIndex: 999,
        }}
        onClick={() => {
          const element = (
            <div style={{ padding: '20px 40px' }}>
              <Analyze isExport={true} />
            </div>
          )
          // 获取组件的 html
          exportElement(element, `巡检报告_.html`)
        }}
      >
        按钮
      </Button>
      <Analyze />
    </>
  )
}

export default App
