export const  data = [
  {
    key: '0',
    ip: '11.166.78.112',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },
  {
    key: '0',
    ip: '11.166.78.112',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },

  
  

  {
    key: '0',
    ip: '11.166.78.112',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },
  {
    key: '1',
    ip: '11.166.78.113',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },
  {
    key: '1',
    ip: '11.166.78.113',
    zone:'zone1',
    assTenant: 'tenant2',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },

  {
    key: '1',
    ip: '11.166.78.112',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:444,
      end:231
    },
    leader:{
      start:200,
      end:123
    }
  },
  {
    key: '1',
    ip: '11.166.78.113',
    zone:'zone1',
    assTenant: 'tenant3',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },

  {
    key: '2',
    ip: '11.166.78.112',
    zone: 'zone1',
    assTenant: 'tenant1',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },
  {
    key: '2',
    ip: '11.166.78.112',
    zone:'zone1',
    assTenant: 'tenant2',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },
  {
    key: '2',
    ip: '11.166.78.112',
    zone:'zone1',
    assTenant: 'tenant3',
    disk: {
      start:7763,
      end:5103
    },
    leader:{
      start:7763,
      end:5103
    }
  },


]